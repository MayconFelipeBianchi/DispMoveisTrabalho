package com.example.trabalhopaulinhodispmov;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edNome, edEmail, edIdade, edDisciplina, edPriBim, edSegBim;
    Button btConfirmar, btLimpar;
    TextView tvNomeRes, tvIdadeRes, tvEmailRes, tvDisciplinaRes, tvNotasRes, tvMediaRes, tvMsgRes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edNome = findViewById(R.id.nome);
        edEmail = findViewById(R.id.email);
        edIdade = findViewById(R.id.idade);
        edDisciplina = findViewById(R.id.disciplina);
        edPriBim = findViewById(R.id.priBimestre);
        edSegBim = findViewById(R.id.segBimestre);
        btConfirmar = findViewById(R.id.btConfirmar);
        btLimpar = findViewById(R.id.btLimpar);
        tvNomeRes = findViewById(R.id.tvNomeRes);
        tvEmailRes = findViewById(R.id.tvEmailRes);
        tvIdadeRes = findViewById(R.id.tvIdadeRes);
        tvDisciplinaRes = findViewById(R.id.tvDisciplinaRes);
        tvNotasRes = findViewById(R.id.tvNotasRes);
        tvMediaRes = findViewById(R.id.tvMediaRes);
        tvMsgRes = findViewById(R.id.tvMsgRes);

        btConfirmar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                verificarEntradas();
            }
        });

        btLimpar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                limparCampos();
            }
        });
    }

    private void verificarEntradas() {
        String nome = edNome.getText().toString();
        String email = edEmail.getText().toString();
        String idadeStr = edIdade.getText().toString();
        String disciplina = edDisciplina.getText().toString();
        String priBimStr = edPriBim.getText().toString();
        String segBimStr = edSegBim.getText().toString();
        String msg = "";

        if (nome.equals("")) {
            msg = "Nome vazio";
        }
        if (email.equals("")) {
            msg = "Email vazio";
        }
        if (disciplina.equals("")) {
            msg = "Disciplina vazia";
        }
        if (idadeStr.equals("") || !Numerico(idadeStr)) {
            msg = "Idade não válida";
        }
        if (priBimStr.equals("") || !NotaValida(priBimStr)) {
            msg = "Nota 1 inválida";
        }
        if (segBimStr.equals("") || !NotaValida(segBimStr)) {
            msg = "Nota 2 inválida";
        }

        if (!msg.equals("")) {
            tvMsgRes.setText(msg);
        } else {
            tvNomeRes.setText(nome);
            tvEmailRes.setText(email);
            tvIdadeRes.setText(idadeStr);
            tvDisciplinaRes.setText(disciplina);
            tvNotasRes.setText("Notas: " + priBimStr + ", " + segBimStr);
            tvMediaRes.setText(calcularMedia(priBimStr, segBimStr));
        }
    }

    private boolean Numerico(String str) {
        try {
            int num = Integer.parseInt(str);
            return num > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean NotaValida(String str) {
        try {
            double nota = Double.parseDouble(str);
            if(nota >= 0 && nota <= 10){return true;
            }else{
                return  false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void limparCampos() {
        edNome.setText("");
        edEmail.setText("");
        edIdade.setText("");
        edDisciplina.setText("");
        edPriBim.setText("");
        edSegBim.setText("");
        tvNomeRes.setText("");
        tvEmailRes.setText("");
        tvIdadeRes.setText("");
        tvDisciplinaRes.setText("");
        tvNotasRes.setText("");
        tvMediaRes.setText("");
        tvMsgRes.setText("");
    }

    private String calcularMedia(String nota1, String nota2) {
        double n1 = Double.parseDouble(nota1);
        double n2 = Double.parseDouble(nota2);
        double media = (n1 + n2) / 2;
        return String.valueOf(media);
    }
}
